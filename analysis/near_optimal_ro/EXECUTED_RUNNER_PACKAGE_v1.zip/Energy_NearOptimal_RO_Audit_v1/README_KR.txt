﻿Energy manuscript near-optimal RO-capacity robustness audit

실행 파일
RUN_NEAROPT_RO_AUDIT.bat 하나만 실행하십시오.

목적
현재 논문의 25개 demand condition에서 feedwater-omitting benchmark가 fully coupled reference보다
낮은 RO capacity를 선택한다는 결과가 하나의 solver-selected capacity vector에만 의존하는지 확인합니다.

검증 방법
- 각 25개 condition에서 C1(reference)과 C2(benchmark)를 각각 다시 풉니다.
- 기준 economic objective J*는 기존 원고보다 엄격한 relative MIP-gap target 1e-6로 구합니다.
- epsilon = 1e-4를 사용하여 J <= (1+epsilon)J*인 near-optimal set을 정의합니다.
- 동일한 물리모델과 동일한 입력에서 K_RO를 별도로 최소화하고 최대화합니다.
- 따라서 condition당 C1 3회 + C2 3회, 총 150개의 annual MILP가 실행됩니다.

중요
이 테스트는 새로운 sensitivity study가 아닙니다.
기존 논문의 capacity-selection 결과에 대한 numerical robustness audit입니다.
C3 fixed-capacity re-evaluation이나 hard-service 결과는 변경하지 않습니다.

주요 출력
results\UPLOAD_NEAROPT_RO_AUDIT_RESULT_YYYYMMDD_HHMMSS.zip

해당 ZIP 하나를 업로드하면 됩니다. ZIP에는 다음이 포함됩니다.
- RO_AUDIT_ALL_RUNS.csv
- RO_AUDIT_PAIRWISE_RANGES.csv
- RO_AUDIT_SUMMARY.txt
- 각 solve의 summary/capacity CSV
- stdout/stderr logs
- 실행 configuration과 file hashes

판정
STRICT_SEPARATION:
  benchmark의 epsilon-optimal 최대 RO capacity가 reference의 epsilon-optimal 최소 RO capacity보다 낮음.
OVERLAP_OR_TOUCH:
  두 epsilon-optimal RO-capacity interval이 겹치거나 접함.

OVERLAP_OR_TOUCH가 나와도 계산 오류를 의미하지 않습니다.
그 경우 논문의 25/25 optimum-selection 결과와 near-optimal range 결과를 구분하여 해석하면 됩니다.

예상 실행시간
총 150개의 annual MILP이므로 기존 core test보다 길게 걸립니다.
실제 ETA는 실행된 solve의 평균시간을 이용해 콘솔에서 계속 갱신됩니다.
각 solve의 time limit은 3600 s입니다.
