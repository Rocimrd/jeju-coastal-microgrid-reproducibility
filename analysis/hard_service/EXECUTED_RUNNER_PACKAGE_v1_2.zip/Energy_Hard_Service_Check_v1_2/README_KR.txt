﻿Hard-service feasibility check package v1.2

[v1.2 correction]
- A verified MSBuild success in v1.1 could be misclassified by the PowerShell runner because of a native-process exit-code handling issue.
- v1.2 removes any stale executable before building and accepts a build only when a fresh executable is created and the build script emits its explicit [OK] success marker.
- No optimization equation, parameter, input data, or hard-service constraint was changed from v1.1.

Energy manuscript - hard-service feasibility check

목적
이 패키지는 본 논문의 selected high-feedwater-burden condition에서 다음 한 가지 질문만 검증합니다.

- Community freshwater demand scale: 50%
- External H2 service: 8,000 kg-H2/day
- Carbon price: 150 USD/tCO2-eq
- Symmetric PCC limit: 1.5 MW
- Feedwater-omitting benchmark에서 산정된 9개 설비용량을 모두 고정
- Electrolyzer feedwater coupling을 full-coupled water balance에 복원
- 모든 시간에서 freshwater shortage = 0
- 모든 시간에서 H2 shortage = 0

즉, benchmark에서 선택된 설비용량을 하나도 변경하지 않고 두 서비스를 동시에 완전 공급할 수 있는지를 확인합니다.

실행 방법
1. ZIP을 짧은 영문 경로에 압축 해제합니다. 예: C:\Energy_Hard_Service_Check_v1_2
2. RUN_HARD_SERVICE_CHECK.bat만 실행합니다.
3. 다른 파일을 직접 실행할 필요가 없습니다.

필요 환경
- Windows x64
- IBM ILOG CPLEX Optimization Studio 22.1.2
- Visual Studio 또는 Build Tools의 C++/MSBuild
- 프로젝트 기본 toolset을 사용할 수 없으면 runner가 v143으로 한 번 자동 재시도합니다.

자동 수행 단계
1. 입력/파라미터/source patch 사전검증
2. Release x64 빌드
3. 50% water / 8,000 kg-H2/day feedwater-omitting benchmark sizing 재실행
4. 일반 fixed-capacity re-evaluation 재실행 및 논문 결과 재현 gate
5. 두 shortage를 모두 0으로 강제한 hard-service feasibility check

중요한 gate
3~4단계에서 논문의 selected benchmark capacity와 5,918 m3/yr freshwater-shortage 결과가 충분히 재현되지 않으면 5단계의 과학적 판정을 사용하지 않습니다.

결과 판정
A. DIAGNOSTIC_STATUS = INFEASIBLE
benchmark-derived fixed capacities로는 feedwater coupling 복원 후 freshwater와 external H2를 동시에 완전 공급할 수 없다는 뜻입니다. Shortage coefficient의 상대비는 shortage를 어느 서비스에 배분할지에는 영향을 줄 수 있지만, 두 서비스를 동시에 만족하지 못하는 inherited portfolio의 물리적/운영적 제약 자체를 만든 것은 아닙니다.

B. DIAGNOSTIC_STATUS = FEASIBLE
동일한 fixed capacities에서도 두 shortage를 모두 0으로 만드는 annual dispatch가 존재한다는 뜻입니다. 따라서 기존 5,918 m3/yr freshwater shortage는 불가피한 capacity infeasibility가 아니라 adopted penalized objective에서 선택된 operating/service-allocation outcome으로 해석해야 합니다.

C. DIAGNOSTIC_STATUS = INCONCLUSIVE
time limit 또는 다른 solver 종료상태 때문에 feasible/infeasible 여부가 확정되지 않은 경우입니다. 이 결과로는 원고 해석을 변경하지 않습니다.

결과 파일
각 실행은 results\hard_service_run_YYYYMMDD_HHMMSS\ 아래에 다음 파일을 남깁니다.
- HARD_SERVICE_RESULT.txt
- HARD_SERVICE_RESULT.csv
- RUN_LOG.txt
- 각 C2/C3/hard-service summary, capacity, dispatch 파일

또한 results 폴더에 UPLOAD_HARD_SERVICE_RESULT_YYYYMMDD_HHMMSS.zip을 자동 생성합니다.
실행이 끝나면 해당 ZIP을 다음 검토 단계에 업로드하면 됩니다.

예상 시간
기존 core run 기록상 benchmark sizing과 일반 re-evaluation은 통상 수분 이내에 끝나는 수준입니다. Hard-service infeasibility를 증명하는 계산은 더 오래 걸릴 수 있으며, 해당 solve의 CPLEX time limit은 3,600 s입니다.

모델 변경 범위
기존 최종 source에서 hard-service case ID가 사용될 때에만 다음 두 제약을 추가합니다.
- Wsh[t] = 0 for all t
- Hsh[t] = 0 for all t

그 외 objective, capacity bounds, input data, market-price policy, carbon price, PCC limit, conversion coefficients, storage dynamics 및 기존 C1/C2/C3 formulation은 변경하지 않습니다.


버전 이력
- v1.1: PowerShell parser 오류 수정 및 실행 전 syntax precheck 추가.
- v1.2: 성공한 MSBuild를 실패로 오판하던 build gate 수정.
